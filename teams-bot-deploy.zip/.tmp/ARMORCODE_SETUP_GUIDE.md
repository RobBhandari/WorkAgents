# ArmorCode Vulnerability Tracking - Setup Guide

## ✅ Implementation Complete!

All scripts, directives, and documentation are ready. You just need the API key to start using it.

---

## 🔑 Step 1: Get API Key from Your Admin

You don't have permission to create API keys yourself. Contact your ArmorCode administrator (Stuart Crawford, Simion-Remus Timis, or Hao Xian Chung based on the API keys list).

### Email Template to Send:

```
Subject: Request for ArmorCode API Key - Vulnerability Tracking Automation

Hi [Admin Name],

I'm setting up an automated vulnerability tracking system for HIGH and CRITICAL
vulnerabilities in our production environment. I need an ArmorCode API key with
the following specifications:

API Key Requirements:
- Token Name: Vulnerability_Tracking_Script_RobBhandari
- API Role: Read Only
- Product: All (or specify specific products if needed)
- Expiry: 90+ days (or per your policy)
- Account Level Access: No
- Purpose: Automated vulnerability tracking with baseline comparison and HTML
  reporting. Will track progress toward 70% reduction goal by June 30, 2026.

The script will:
- Query ArmorCode API for HIGH and CRITICAL vulnerabilities
- Generate HTML reports with baseline comparison
- Email reports to stakeholders automatically
- No write access needed - read-only queries only

Location to create: ArmorCode UI → Manage → Integrations → ArmorCode API → Create New Key

Once created, please securely share the API key with me.

Thanks!
Rob Bhandari
```

---

## 📋 Step 2: Once You Have the API Key

### 2.1 Add API Key to .env
Edit `c:\DEV\Agentic-Test\.env` and replace:
```bash
ARMORCODE_API_KEY=your_armorcode_api_key_here
```

With your actual key:
```bash
ARMORCODE_API_KEY=xxxx-xxxx-xxxx-xxxx
```

### 2.2 Configure Email Recipients
Update in `.env`:
```bash
ARMORCODE_EMAIL_RECIPIENTS=robin.bhandari@theaccessgroup.com,other@company.com
```

---

## 🚀 Step 3: Run Product Discovery

```bash
python execution/armorcode_list_products.py
```

This will:
- Test your API connection
- Show all available products
- Save results to `.tmp/armorcode_products.json`

Then update `.env` with products you want to track:
```bash
ARMORCODE_PRODUCTS=Product1,Product2,Product3
```

---

## 📊 Step 4: Create Baseline (One-Time)

```bash
python execution/armorcode_baseline.py
```

This creates an immutable snapshot of vulnerabilities on 2026-01-01.

Output saved to: `.tmp/armorcode_baseline.json`

---

## 🧪 Step 5: Test Full Workflow

```bash
cd execution
run_armorcode_report.bat
```

This will:
1. Query current vulnerabilities
2. Generate HTML report with baseline comparison
3. Email report to configured recipients

---

## 📅 Step 6: Schedule Automated Reports

### Option A: Windows Task Scheduler (GUI)
1. Open Task Scheduler (Win+R → `taskschd.msc`)
2. Create Basic Task
3. Name: `ArmorCode_Vulnerability_Report`
4. Trigger: Your custom schedule (e.g., Weekly Monday 8 AM)
5. Action: Start a program
   - Program: `cmd.exe`
   - Arguments: `/c "c:\DEV\Agentic-Test\execution\run_armorcode_report.bat"`
   - Start in: `c:\DEV\Agentic-Test`

### Option B: PowerShell
```powershell
$action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument '/c "c:\DEV\Agentic-Test\execution\run_armorcode_report.bat"' -WorkingDirectory "c:\DEV\Agentic-Test"
$trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday -At 8am
Register-ScheduledTask -TaskName "ArmorCode_Vulnerability_Report" -Action $action -Trigger $trigger
```

---

## 📖 Documentation

### Main Files Created:
1. **Directive** (SOP): `directives/armorcode_vulnerabilities.md`
2. **Scripts**:
   - `execution/armorcode_list_products.py` - Product discovery
   - `execution/armorcode_baseline.py` - Baseline creation
   - `execution/armorcode_query_vulns.py` - Query & comparison
   - `execution/armorcode_report_to_html.py` - HTML report
   - `execution/send_armorcode_report.py` - Email delivery
   - `execution/run_armorcode_report.bat` - Full workflow

### Configuration:
- **Environment**: `.env` file
- **Requirements**: `requirements.txt` (no SDK needed, uses REST API)

---

## 🎯 What the System Does

### Baseline Tracking
- **Date**: January 1, 2026
- **Scope**: HIGH + CRITICAL vulnerabilities in PRODUCTION
- **Goal**: 70% reduction by June 30, 2026 (30% remaining)

### Progress Reports Show:
- **Baseline Count**: Vulnerabilities on 2026-01-01
- **Target Count**: 30% of baseline
- **Current Count**: Today's vulnerability count
- **Reduction %**: How much has been reduced
- **Progress to Goal %**: How far along toward 70% reduction
- **Timeline**: Days since baseline, days to target

### HTML Report Includes:
1. **Executive Summary**: Large cards with key metrics
2. **Trend Chart**: Historical progress over time (builds as you run queries)
3. **Vulnerability Table**: Sortable, searchable, color-coded by severity
4. **Statistics**: Breakdown by severity, product, status

### Email Delivery:
- Subject: "ArmorCode Vulnerability Report - [Date] - [Count] vulns ([Progress]% to goal)"
- Body: Text summary with key metrics
- Attachment: Full HTML report

---

## 🔧 Troubleshooting

### API Key Not Working?
- Check it's copied correctly (no extra spaces)
- Verify it has "Read Only" permissions
- Check expiry date hasn't passed

### No Products Found?
- Verify your API key has access to products
- Check ARMORCODE_BASE_URL is correct
- Check logs in `.tmp/armorcode_list_products_*.log`

### Email Not Sending?
- Verify Microsoft Graph API credentials in `.env`:
  - `AZURE_TENANT_ID`
  - `AZURE_CLIENT_ID`
  - `AZURE_CLIENT_SECRET`
  - `EMAIL_ADDRESS`

### Script Errors?
- Check logs in `.tmp/` directory
- Each script creates its own log file with timestamp
- Logs show detailed error messages and API responses

---

## 📞 Support

- **Full Documentation**: `directives/armorcode_vulnerabilities.md`
- **Architecture Guide**: `AGENTS.md`
- **Main README**: `README.md`

---

## ✨ Summary

**Status**: Implementation complete! Ready to use once you have the API key.

**Next Action**: Contact your ArmorCode admin to request an API key using the email template above.

**Then**: Follow Steps 2-6 in this guide to configure and test the system.

**Result**: Automated vulnerability tracking with beautiful HTML reports showing progress toward your 70% reduction goal! 🎉

---

**Created**: 2026-01-30
**System**: DOE (Directives · Orchestration · Execution) Framework
**Platform**: ArmorCode vulnerability management
