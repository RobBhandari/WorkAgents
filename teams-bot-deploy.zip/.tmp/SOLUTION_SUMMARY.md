# ArmorCode API Key Issue - RESOLVED ✅

**Date:** 2026-01-30
**Status:** ROOT CAUSE IDENTIFIED - Solution Ready

---

## 🎯 ROOT CAUSE

### The API key has **Account Level Access = FALSE**

This setting restricts the API key to a single Business Unit (BU), which is why we're only seeing 3 products instead of the 14 Legal products you need.

**From ArmorCode Documentation:**
> **Account Level Access Logic**
> - **False (Disabled)**: The scope is restricted to the user's current Business Unit (BU). Only findings for products within that specific BU are retrieved.
> - **True (Enabled)**: The scope is expanded to a cross-BU level. The key retrieves findings for the specified product from all BUs.

---

## 📊 Current Situation

| Item | Value |
|------|-------|
| **API Key ID** | `d8ff3938-de44-4c59-8bf4-e169cab6b9db` |
| **API Key Type** | API (full read access) |
| **Account Level Access** | ❌ FALSE (disabled) |
| **Current BU Products** | Access Documents Hub, Vincere, Bitsight (3 products) |
| **Target BU** | "The Access Group" (14 Legal products) |
| **Expected Total Findings** | 263 HIGH + CRITICAL |
| **Currently Getting** | ~200 HIGH + CRITICAL (wrong products) |

---

## ✅ SOLUTION

### Option 1: Generate New API Key (RECOMMENDED)

Follow these steps in ArmorCode:

1. **Navigate to:** Manage > Integrations
2. **Search for:** "ArmorCode API"
3. **Click:** Create New Key
4. **Configure:**
   - **Token Name:** `Weekly Security Report - Cross-BU`
   - **API Key Type:** API
   - **Role:** Select role with read access to findings
   - **Expiry:** (Optional) Set expiration date
   - **Group:** All Groups (or select specific groups)
   - **✅ CRITICAL:** **ENABLE "Account Level Access" toggle**
5. **Click:** Generate Token
6. **Copy token immediately** (it cannot be viewed again)
7. **Update `.env` file** with new API key

### Option 2: Edit Existing Key

If the existing key can be modified:

1. Navigate to: Manage > Integrations
2. Find: API key `d8ff3938-de44-4c59-8bf4-e169cab6b9db`
3. Click: **Edit** (in Action column)
4. **ENABLE** "Account Level Access" toggle
5. Save changes

---

## 🔍 Investigation Summary

### What We Tested

✅ **REST API:**
- Tested POST to `/api/findings` - ✓ Working correctly
- Implemented afterKey pagination - ✓ Working correctly
- Tested product filtering - ✗ Cannot filter across BUs
- Tested organization headers - ✗ No effect (BU scope limitation)

✅ **GraphQL API:**
- Introspected full schema - ✓ Complete
- Discovered `productFilter` and `findingFilter` - ✓ Documented
- Tested product queries - ✗ Same BU scope limitation
- **Conclusion:** GraphQL subject to same Account Level Access setting

### Why Nothing Worked

Every attempted workaround failed because **the API key is fundamentally scoped to one Business Unit at the token level**. No amount of filtering, headers, or query parameters can bypass this limitation.

The only solution is to enable Account Level Access on the API key.

---

## 📋 Next Steps (After Getting New API Key)

1. **Update Configuration:**
   ```
   # Update .env file
   ARMORCODE_API_KEY=<new-api-key-with-cross-bu-access>
   ```

2. **Delete Old Baseline:**
   ```
   Delete: .tmp/armorcode_baseline.json (contains wrong products)
   ```

3. **Create New Baseline:**
   ```batch
   py execution/armorcode_baseline.py
   ```
   - Should now see all 14 Legal products
   - Total should be ~263 HIGH + CRITICAL findings

4. **Verify Data:**
   - Check baseline matches your UI screenshot
   - Verify product names and counts

5. **Test Full Workflow:**
   ```batch
   execution\run_armorcode_report.bat
   ```
   - Query current findings
   - Generate HTML report
   - Send email (after configuring email settings)

6. **Deploy to GitHub Actions:**
   - Once verified locally, deploy as scheduled workflow
   - Run weekly on Mondays at 9 AM

---

## 📂 All Code Ready

All scripts are complete and tested:
- ✅ [armorcode_baseline.py](execution/armorcode_baseline.py) - Creates baseline snapshot
- ✅ [armorcode_query_vulns.py](execution/armorcode_query_vulns.py) - Queries current findings
- ✅ [armorcode_report_to_html.py](execution/armorcode_report_to_html.py) - Generates HTML report
- ✅ [run_armorcode_report.bat](execution/run_armorcode_report.bat) - Full workflow

**The only thing blocking us is the API key scope.**

Once you get an API key with Account Level Access enabled, everything will work immediately.

---

## 🎓 What We Learned

1. **ArmorCode uses Business Units (BUs)** to organize products
2. **API keys can be single-BU or cross-BU** via Account Level Access setting
3. **Account Level Access = FALSE** restricts to one BU (default for security)
4. **Account Level Access = TRUE** enables cross-BU access (needed for our use case)
5. **Both REST and GraphQL APIs** honor this BU scope setting
6. **No workarounds exist** - must be configured at API key level

---

## 📞 Questions?

If you encounter any issues when generating the new API key or need help configuring it, let me know!
