# ArmorCode API Investigation Summary

**Date:** 2026-01-30
**Status:** API Key Scope Issue Identified

## Key Findings

### 1. API Key is Scoped to Different Products

The current API key **ONLY** has access to:
- **Access Documents Hub** (120 HIGH+CRITICAL findings)
- **Vincere** (60 findings)
- **Bitsight - External Security Posture** (20 findings)

**Missing Products** (from your UI - CRITICAL + HIGH only):
- **Access Legal Case Management**: 68 (2 C + 66 H)
- **Access Legal Compliance**: 51 (2 C + 49 H)
- **Access Legal Framework**: 30 (0 C + 30 H)
- **Eclipse**: 26 (5 C + 21 H)
- **Law Fusion**: 16 (0 C + 16 H)
- **Legal Bricks**: 15 (0 C + 15 H)
- **One Office & Financial Director**: 15 (0 C + 15 H)
- **Access MyCalendars**: 13 (0 C + 13 H)
- **Legal Workspace**: 13 (0 C + 13 H)
- **Access Legal AI Services**: 9 (0 C + 9 H)
- **inCase**: 5 (0 C + 5 H)
- **Access Diversity**: 2 (0 C + 2 H)
- **Proclaim**: 0 (0 C + 0 H)
- **Proclaim Portals - Eclipse**: 0 (0 C + 0 H)

**Total Expected**: **263 HIGH + CRITICAL findings** across these Legal products

### 2. No Organization/Hierarchy Fields in API Response

Findings returned by the API contain **NO** organization or hierarchy identifiers:
- `armorcodeProjects`: Always `null`
- No `organization` field
- No `hierarchy` field
- Only has: `product`, `subProduct`, `team`, `owner`

### 3. API Endpoints Tested (All 404)

These endpoints do NOT exist:
- `/api/products` - 404
- `/api/organizations` - 404
- `/api/hierarchies` - 404
- `/api/projects` - 404
- `/api/user/info` - 404

### 4. Product Filtering Doesn't Work

We tested these filter parameters (NONE worked):
- `products: [...]`
- `product: [...]`
- `productNames: [...]`
- `hierarchy: [...]`
- `team: [...]`

**All filters are ignored** - API always returns same 3 products.

### 5. Pagination Works

Successfully implemented cursor-based pagination:
- Uses `afterKey` parameter
- Returns 10 findings per page
- Can fetch 200+ findings across multiple pages

## ROOT CAUSE IDENTIFIED ✅

### Account Level Access Setting

**The API key is scoped to a single Business Unit (BU) because "Account Level Access" is DISABLED.**

From ArmorCode documentation:
> **Account Level Access Logic**
> - **False (Disabled)**: The scope is restricted to the user's current Business Unit (BU). Only findings for products within that specific BU are retrieved.
> - **True (Enabled)**: The scope is expanded to a cross-BU level. The key retrieves findings for the specified product from all BUs.

**Current Situation:**
- API Key ID: `d8ff3938-de44-4c59-8bf4-e169cab6b9db`
- Account Level Access: **FALSE** (disabled)
- Current BU products: Access Documents Hub, Vincere, Bitsight
- Target BU: "The Access Group" (Legal products)

**This explains:**
1. Why we only see 3 products instead of 14
2. Why product filtering doesn't work (products are in different BU)
3. Why no organization/hierarchy fields exist (API is BU-scoped)

## Solution Required

### Generate New API Key with Account Level Access

Follow these steps in ArmorCode:

1. **Navigate to Manage > Integrations**
2. **Search for "ArmorCode API" and click "Create New Key"**
3. **Configure the new key:**
   - Token Name: `Weekly Security Report - Cross-BU`
   - API Key Type: **API**
   - Role: Select appropriate role (read access to findings)
   - Expiry: (Optional) Set expiration date
   - Group: Select "All Groups" or specific groups
   - **✅ ENABLE "Account Level Access" toggle** ← CRITICAL
4. **Click "Generate Token"**
5. **Copy the token immediately** (cannot be viewed again)

### Alternative: Edit Existing Key

If the existing key can be edited:
1. Go to Manage > Integrations
2. Find API key `d8ff3938-de44-4c59-8bf4-e169cab6b9db`
3. Click **Edit** in the Action column
4. **ENABLE "Account Level Access" toggle**
5. Save changes

## Previous Investigation (Before Root Cause Found)

### Questions for ArmorCode Admin (NOW RESOLVED):

1. **API Key Scope:** ✅ RESOLVED
   - API key has Account Level Access = FALSE
   - Only sees products in one Business Unit
   - Need to enable Account Level Access for cross-BU access

2. **Organization/Hierarchy Access:** ✅ RESOLVED
   - "Account Level Access" setting controls BU scope
   - When enabled, API returns findings across all BUs

3. **API Documentation:** ✅ RESOLVED
   - Documentation provided shows Account Level Access setting
   - This is the standard way to access multi-BU data

### Additional Context to Provide:

Show the admin this information:
- **Current API Key ID:** `d8ff3938-de44-4c59-8bf4-e169cab6b9db`
- **API Key Type:** "API" (full read access)
- **Expected Organization:** "The Access Group"
- **Expected Products:** Access Legal Case Management, Legal Bricks, Proclaim, Eclipse, etc.
- **Actually Getting:** Access Documents Hub, Vincere, Bitsight

## Possible Solutions

### Solution 1: New API Key
Create a new API key specifically scoped to:
- **Organization:** "The Access Group"
- **Products:** Select all the Legal products
- **Permissions:** Read access to findings

### Solution 2: Different Authentication
- Check if there's a different auth method for multi-org access
- Service account vs user account token
- Different token scope parameters

### Solution 3: GraphQL API
- The REST API might be limited
- ArmorCode might have a GraphQL API with better filtering
- May need to explore `/graphql` endpoint with proper queries

## What Works So Far

✅ **Successfully Implemented:**
1. API connection via POST to `/api/findings`
2. Cursor-based pagination with `afterKey`
3. Severity filtering (HIGH, CRITICAL)
4. Data extraction and formatting
5. HTML report generation
6. Progress tracking against baseline

⚠️ **Blocked On:**
- Product/Organization filtering (wrong data source)
- Cannot access "The Access Group" products
- Baseline and reports showing wrong products

## Next Steps

1. **Wait for Admin Response** on the 2 questions above
2. **Get new API key** or **correct authentication method**
3. **Re-run baseline creation** with correct products
4. **Verify data** matches UI screenshot
5. **Deploy to GitHub Actions** once working

## Files for Reference

- Current test scripts: `execution/explore_armorcode_api.py`
- Pagination test: `execution/test_full_pagination.py`
- Product scan: `execution/scan_all_products.py`
